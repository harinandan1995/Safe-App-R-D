//
//  main.m
//  M13Checkbox
//
//  Created by Brandon McQuilkin on 12/30/12.
//  Copyright (c) 2012 Brandon McQuilkin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
